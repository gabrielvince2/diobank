export abstract class DioAccount {
  private name: string
  private readonly accountNumber: number
  balance: number = 0
  private status: boolean = true

  constructor(name: string, accountNumber: number){
    this.name = name
    this.accountNumber = accountNumber
  }

  setName = (doc_id: number, name: string): void => {
    if(this.validateStatus(doc_id)){
      this.name = name
      console.log('Nome alterado com sucesso para '+name)
    }
  }

  getName = (doc_id: number): string => {
    return this.name
  }


  getAccountNumber = (): number => {
    return this.accountNumber;
  }

  deposit = (doc_id: number, money: number): void => {
    if(this.validateStatus(doc_id)){
      this.balance += money;
    }
  }

  isAvailabe = (money: number): boolean => {
    if(this.balance >= money){
      return true
    }
    else{
      return false
    }
  }

  withdraw = (doc_id: number, money: number): void => {
    if(this.validateStatus(doc_id)){
    if(this.isAvailabe(money)){
      this.balance -= money;
      console.log("Você sacou "+money+". Seu saldo agora é "+this.balance)
    }
    else{
      console.log("Você não tem saldo o suficiente")
    }
  }
  }
  getBalance = (): void => {
    console.log(this.balance)
  }
 
  public validateStatus = (doc_id: number): boolean => {
    if(doc_id == this.accountNumber){
      return true;
    }
    else{
      console.log("Sua conta não foi encontrada")
      return false
    }
  }



}
