import { DioAccount } from "./DioAccount"

export class CompanyAccount extends DioAccount {

  constructor(name: string, accountNumber: number){
    super(name, accountNumber)
  }

  getLoan = (doc_company: number, doc_people: number, money: number): void => {
    if(this.validateStatus(doc_company)){
      if(this.validateStatus(doc_people)){
        
      }
    }
  }
}
