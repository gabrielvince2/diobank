import { CompanyAccount } from './class/CompanyAccount'
import { PeopleAccount } from './class/PeopleAccount'

const peopleAccount: PeopleAccount = new PeopleAccount('GAbriel Vince', 12345)
const companyAccount: CompanyAccount = new CompanyAccount('DIO', 6789)

peopleAccount.deposit(12345,100)
companyAccount.deposit(6789,500)

peopleAccount.withdraw(12345,50)


var transferAccounts = (empresa: CompanyAccount, pessoa: PeopleAccount, money: number): void => {
    var contaEmpresa = empresa.getAccountNumber()
    var contaPessoa = pessoa.getAccountNumber()

    if(empresa.validateStatus(contaEmpresa)){
        if(pessoa.validateStatus(contaPessoa)){
            empresa.withdraw(contaEmpresa, money)
            pessoa.deposit(contaPessoa, money)

            empresa.getBalance()
            pessoa.getBalance()
        }
    }

}


transferAccounts(companyAccount, peopleAccount, 500);